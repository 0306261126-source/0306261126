#include <iostream>
#include <iomanip>

using namespace std;

int main() {
    int daLam, keHoach;
    cout << "Nhap so san pham da lam va ke hoach: ";
    cin >> daLam >> keHoach;
    double tyLe = 100.0 * daLam / keHoach;

    cout << fixed << setprecision(2);
    cout << "Ty le hoan thanh: " << tyLe << "%" << endl;
    if (daLam >= keHoach) {
        cout << "Da dat ke hoach" << endl;
    }
    else {
        int conThieu = keHoach - daLam;
        cout << "Chua dat ke hoach, so san pham con thieu: " << conThieu << endl;
    }

    return 0;
}