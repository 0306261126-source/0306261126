#include <iostream>
using namespace std;

int main() {
    char bocQua = 'K';
    long long phi = 0;
    if (bocQua == 'C') {
        phi = 6000;
    }

    cout << bocQua << " " << phi << "\n";
    return 0;
}
// Sửa toán tử gán = thành so sánh ==
