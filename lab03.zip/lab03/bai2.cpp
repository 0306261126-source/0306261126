#include <iostream>

using namespace std;

int main() {
    int n, k;
    cout << "Nhap so nguoi (n) va so cho moi xe (k): ";
    cin >> n >> k;
    int soXe = n / k;
    if (n % k > 0) {
        soXe++;
    }
    int gheTrong = 0;
    if (soXe > 0) {
        gheTrong = soXe * k - n;
    }
    cout << "So xe can thue: " << soXe << endl;
    cout << "Tong so ghe trong: " << gheTrong << endl;

    return 0;
}