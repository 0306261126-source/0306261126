#include <iostream>

using namespace std;

int main() {
    long long tienHang;
    char bocQua;
    int nhanh;

    cout << "Nhap tien hang, boc qua (C/K), xu ly nhanh (1/0): ";
    cin >> tienHang >> bocQua >> nhanh;

    long long phiBocQua = 0;
    long long phiNhanh = 0;
    if (bocQua == 'C' || bocQua == 'c') {
        phiBocQua = 6000;
    }
    if (nhanh == 1) {
        phiNhanh = 12000;
    }

    long long tongPhuPhi = phiBocQua + phiNhanh;
    long long tongThanhToan = tienHang + tongPhuPhi;

    cout << "Phi boc qua: " << phiBocQua << " dong" << endl;
    cout << "Phi xu ly nhanh: " << phiNhanh << " dong" << endl;
    cout << "Tong phu phi: " << tongPhuPhi << " dong" << endl;
    cout << "Tong thanh toan: " << tongThanhToan << " dong" << endl;

    return 0;
}