#include <iostream>
#include <iomanip>

using namespace std;

int main() {
    double V;
    int n;

    cout << "Nhap so lit nuoc (V) va so binh (n): ";
    cin >> V >> n;
    if (n > 0) {
        double nuocMoiBinh = V / n;
        cout << fixed << setprecision(2);
        cout << "Luong nuoc moi binh: " << nuocMoiBinh << " lit" << endl;
    }
    else {
        cout << "So binh khong hop le\n";
    }

    return 0;
}