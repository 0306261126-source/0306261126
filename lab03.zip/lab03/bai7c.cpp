#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    int daLam = 2, keHoach = 3;
    double tiLe = (double)daLam / keHoach * 100;

    cout << fixed << setprecision(2) << tiLe << "\n";
    return 0;
}
// Ép kiểu ép thành phép chia thực
