#include <iostream>
#include <iomanip>

using namespace std;

int main() {
    char maDungCu;
    int soLuong;
    int soPhut;
    long long donGiaPhut;
    cout << "Nhap ma dung cu (B/V): ";
    cin >> maDungCu;
    cout << "Nhap so luong: ";
    cin >> soLuong;
    cout << "Nhap thoi luong thue (phut): ";
    cin >> soPhut;
    cout << "Nhap don gia/phut: ";
    cin >> donGiaPhut;
    long long tienThue = (long long)soLuong * soPhut * donGiaPhut;
    int gio = soPhut / 60;
    int phutDu = soPhut % 60;
    double thoiGianQuyDoi = (double)soPhut / 60.0;
    bool duocTangNuoc = (soPhut >= 120) && (tienThue >= 100000);
    cout << "\n--- PHIEU THUE ---" << endl;
    cout << "Ma dung cu: " << maDungCu << endl;
    cout << "So luong: " << soLuong << endl;
    cout << "Thoi luong: " << gio << " gio " << phutDu << " phut" << endl;
    cout << fixed << setprecision(2);
    cout << "Quy doi: " << thoiGianQuyDoi << " gio" << endl;
    cout << "Tien thue: " << tienThue << " dong" << endl;
    cout << boolalpha;
    cout << "Duoc tang nuoc: " << duocTangNuoc << endl;
    return 0;
}