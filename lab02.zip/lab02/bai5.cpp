#include <iostream>

using namespace std;

int main() {
    int N;
    cout << "Nhap ma so 3 chu so (100-999): ";
    cin >> N;
    int hangTram = N / 100;
    int phanConLai = N % 100;
    int hangChuc = phanConLai / 10;
    int hangDonVi = phanConLai % 10;
    int tong = hangTram + hangChuc + hangDonVi;
    cout << "Hang tram: " << hangTram << endl;
    cout << "Hang chuc: " << hangChuc << endl;
    cout << "Hang don vi: " << hangDonVi << endl;
    cout << "Tong cac chu so: " << tong << endl;
    int soTaiTao = hangTram * 100 + hangChuc * 10 + hangDonVi;
    cout << "Kiem tra tai tao lai so: " << soTaiTao << endl;

    return 0;
}