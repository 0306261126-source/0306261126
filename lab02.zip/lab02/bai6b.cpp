#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    double a = 6.5, b = 7, c = 8;
    double trungBinh = (a + b + c) / 3;
    cout << fixed << setprecision(2) << trungBinh << "\n";
    return 0;
}
//Nguyên nhân: Do thứ tự ưu tiên toán tử, chỉ có c được chia cho 3 (a + b + (c/3))