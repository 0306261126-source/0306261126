#include <iostream>
#include <iomanip>
using namespace std;

int main() {
    int soDung = 17, tongCau = 20;
    double tyLe = (double)soDung / tongCau * 100;
    cout << fixed << setprecision(2) << tyLe << "%\n";
    return 0;
}
//Nguyên nhân: Phép chia nguyên soDung / tongCau cho kết quả 0 trước khi nhân với 100.