#include <iostream>
#include <iomanip>

using namespace std;

int main() {
    int quangDuongKm, soLit;
    cout << "Nhap quang duong (km): ";
    cin >> quangDuongKm;
    cout << "Nhap so lit nhien lieu da dung (lit): ";
    cin >> soLit;
    double mucTieuThu = (double)soLit * 100 / quangDuongKm;
    cout << fixed << setprecision(2);
    cout << "Muc tieu thu: " << mucTieuThu << " L/100 km" << endl;
    return 0;
}