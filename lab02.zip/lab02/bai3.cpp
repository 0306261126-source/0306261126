#include <iostream>

using namespace std;

int main() {
    int soLuong;
    long long donGia;
    cout << "Nhap so luong: ";
    cin >> soLuong;
    cout << "Nhap don gia (dong): ";
    cin >> donGia;
    long long thanhTien = soLuong * donGia;
    cout << "So luong: " << soLuong << endl;
    cout << "Don gia: " << donGia << " dong" << endl;
    cout << "Thanh tien: " << thanhTien << " dong" << endl;
    return 0;
}