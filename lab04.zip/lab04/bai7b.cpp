#include <iostream>
using namespace std;

int main() {
    double diem = 7;
    if (diem == 10) { // Đã sửa = thành ==
        cout << "Diem toi da\n";
    }
    cout << "Diem sau kiem tra: " << diem << "\n";
    return 0;
}