#include <iostream>
using namespace std;

int main() {
    int coThe = 0;
    int tonKho = 3;

    if (coThe == 1) { // Thêm ngoặc khối lệnh
        if (tonKho > 0) {
            cout << "Cho muon\n";
        }
        else {
            cout << "Het dung cu\n";
        }
    }
    else {
        cout << "Can the hop le\n";
    }

    return 0;
}