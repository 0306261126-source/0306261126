#include <iostream>

using namespace std;

int main() {
    double khoiLuong;
    long long phi = 0;

    cout << "Nhap khoi luong kien hang (kg): ";
    cin >> khoiLuong;
    if (khoiLuong <= 5.0) {
        phi = 20000;
    }
    else {
        phi = 35000;
    }

    cout << "Khoi luong: " << khoiLuong << " kg" << endl;
    cout << "Phi gui: " << phi << " dong" << endl;

    return 0;
}