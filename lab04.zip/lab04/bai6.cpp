#include <iostream>
#include <iomanip>

using namespace std;

int main() {
    int a, b;

    cout << "Nhap hai he so a va b: ";
    cin >> a >> b;

    if (a != 0) {
        double x = -1.0 * b / a;
        cout << fixed << setprecision(2);
        cout << "Phuong trinh co 1 nghiem x = " << x << endl;
    }
    else {
        if (b == 0) {
            cout << "Moi so thuc deu la nghiem (vo so nghiem)." << endl;
        }
        else {
            cout << "Phuong trinh khong co nghiem." << endl;
        }
    }

    return 0;
}