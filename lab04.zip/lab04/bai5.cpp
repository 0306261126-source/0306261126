#include <iostream>

using namespace std;

int main() {
    int coThe, tonKho;

    cout << "Nhap trang thai the (1: Co, 0: Khong) va ton kho: ";
    cin >> coThe >> tonKho;
    bool coTheVaKhoCon = (coThe == 1) && (tonKho > 0);
    if (coThe == 1) {
        if (tonKho > 0) {
            tonKho--; 
            cout << "Cho muon mot chiec; ton kho con lai: " << tonKho << endl;
        }
        else {
            cout << "Het dung cu; ton kho giu nguyen bang 0." << endl;
        }
    }
    else {
        cout << "Can the hop le; ton kho giu nguyen." << endl;
    }
    cout << "(Doi chieu 'co the va kho con': " << (coTheVaKhoCon ? "true" : "false") << ")" << endl;

    return 0;
}